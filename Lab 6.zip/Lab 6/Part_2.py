import numpy
import sim
import sys
import time

#-----Try to connect---------------
sim.simxFinish(-1)
clientID = sim.simxStart('10.0.0.51',19999,True,True,10000,5)
if clientID != -1:
    print("Connected to remote API server")
else:
    print("Not connected to remote API server")
    sys.exit ("could not connect")
    
#-----Start the Paused Simulation
err_code = sim.simxStartSimulation(clientID,sim.simx_opmode_oneshot)


#-----Initialize Joint Handles---------
err_code,j1 = sim.simxGetObjectHandle(clientID,"J1",sim.simx_opmode_blocking)
err_code,j2 = sim.simxGetObjectHandle(clientID,"J2",sim.simx_opmode_blocking)
err_code,j3 = sim.simxGetObjectHandle(clientID,"J3",sim.simx_opmode_blocking)

while True:
    print("Hello World")
    pos_val = numpy.radians(30) # in degrees 0
    err_code = sim.simxSetJointTargetPosition (clientID, j1,pos_val,sim.simx_opmode_streaming) # set the postion of J1

    time.sleep(1) #wait a short amount of time

    pos_val = numpy.radians(30) # in degrees 0  
    err_code = sim.simxSetJointTargetPosition (clientID, j2,pos_val,sim.simx_opmode_streaming) # set the postion of J1

    time.sleep(1) #wait a short amount of time

    pos_val = numpy.radians(30) # in degrees 0
    err_code = sim.simxSetJointTargetPosition (clientID, j3,pos_val,sim.simx_opmode_streaming) # set the postion of J1

    time.sleep(1) #wait a short amount of time